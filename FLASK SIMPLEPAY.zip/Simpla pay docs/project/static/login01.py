from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)


connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="clerence",
    database="clerence"
)
cursor = connection.cursor()



@app.route("/forgotpassword")
def forgot_password():
    return render_template("forgotpassword.html")


@app.route("/")
def index():
    
    return render_template("index.html")

@app.route("/submit", methods=["POST"])
def submit():
    username = request.form["username"]
    password = request.form["password"]

    cursor.execute("SELECT * FROM learner_login WHERE username=%s AND password=%s", (username, password))
    result = cursor.fetchone()

    if result:
        
        return render_template("personalInfo.html")
    else:
        
        return render_template("index.html", error="Invalid username or password")

if __name__ == "__main__":
    app.run(debug=True)
