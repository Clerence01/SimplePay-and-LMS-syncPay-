from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector

app = Flask(__name__)
app.secret_key = "supersecretkey"

# MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="clerence",
    database="clerence"
)
cursor = db.cursor()

# ---------------- Step 1: Personal Info ----------------
@app.route("/", methods=["GET", "POST"])
def personal_info():
    if request.method == "POST":
        pi = request.form.to_dict()
        try:
            sql = """
            INSERT INTO Personal_information
            (First_name, Last_name, Title, Name_known_by, ID_no, Passport_number, Country_of_passport,
             Date_of_birth, Marital_status, Tax_reference, No_dependents, Startdate)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
            values = (
                pi.get('first_name'), pi.get('last_name'), pi.get('title'), pi.get('known_by'),
                pi.get('id_number'), pi.get('passport'), pi.get('passport_country'),
                pi.get('dob'), pi.get('marital_status'), pi.get('tax_number'),
                pi.get('dependencies'), pi.get('start_date')
            )
            cursor.execute(sql, values)
            db.commit()
            session['personal_id'] = cursor.lastrowid
        except Exception as e:
            print("Personal Info Error:", e)
            return "Error inserting personal info!"
        return redirect(url_for("contact"))
    return render_template("personalInfo.html")

# ---------------- Step 2: Contact ----------------
@app.route("/contact", methods=["GET", "POST"])
def contact():
    personal_id = session.get('personal_id')
    if personal_id is None:
        return redirect(url_for('personal_info'))

    if request.method == "POST":
        cd = request.form.to_dict()
        try:
            sql = """
            INSERT INTO learner_contact_details
            (personal_id, cellular_number, email)
            VALUES (%s,%s,%s)
            """
            values = (personal_id, cd.get('cell_number'), cd.get('email'))
            cursor.execute(sql, values)
            db.commit()
        except Exception as e:
            print("Contact Error:", e)
            return "Error inserting contact info!"
        return redirect(url_for("next_of_kin"))
    return render_template("contact.html")

# ---------------- Step 3: Next of Kin ----------------
@app.route("/next_of_kin", methods=["GET", "POST"])
def next_of_kin():
    personal_id = session.get('personal_id')
    if personal_id is None:
        return redirect(url_for('personal_info'))

    if request.method == "POST":
        nok = request.form.to_dict()
        try:
            sql = """
            INSERT INTO next_of_kin
            (personal_id, next_of_kin, contact_no)
            VALUES (%s,%s,%s)
            """
            # Ensure the contact number is passed as string
            contact_no = str(nok.get('nok_contact'))
            values = (personal_id, nok.get('nok_name'), contact_no)
            cursor.execute(sql, values)
            db.commit()
        except Exception as e:
            print("Next of Kin Error:", e)
            return f"Error inserting next of kin info: {e}"
        return redirect(url_for("physical_address"))

    return render_template("next_of_kin.html")


# ---------------- Step 4: Physical Address ----------------
@app.route("/physical_address", methods=["GET", "POST"])
def physical_address():
    personal_id = session.get('personal_id')
    if personal_id is None:
        return redirect(url_for('personal_info'))

    if request.method == "POST":
        pa = request.form.to_dict()
        try:
            sql = """
            INSERT INTO Physical_Address
            (personal_id, street_no, street_name, building_unit, suburb, poastal_code, province)
            VALUES (%s,%s,%s,%s,%s,%s,%s)
            """
            values = (
                personal_id, pa.get('street_no'), pa.get('street_name'), pa.get('building_unit'),
                pa.get('suburb'), pa.get('poastal_code'), pa.get('province')
            )
            cursor.execute(sql, values)
            db.commit()
        except Exception as e:
            print("Physical Address Error:", e)
            return "Error inserting physical address!"
        return redirect(url_for("postal_address"))
    return render_template("physical_address.html")

# ---------------- Step 5: Postal Address ----------------
@app.route("/postal_address", methods=["GET", "POST"])
def postal_address():
    personal_id = session.get('personal_id')
    if personal_id is None:
        return redirect(url_for('personal_info'))

    if request.method == "POST":
        poa = request.form.to_dict()
        try:
            sql = """
            INSERT INTO Postal_Address
            (personal_id, street_no, street_name, building_unit, suburb, poastal_code, province, country)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
            """
            values = (
                personal_id, poa.get('street_no'), poa.get('street_name'), poa.get('building_unit'),
                poa.get('suburb'), poa.get('poastal_code'), poa.get('province'), poa.get('country')
            )
            cursor.execute(sql, values)
            db.commit()
        except Exception as e:
            print("Postal Address Error:", e)
            return "Error inserting postal address!"
        return redirect(url_for("uploads"))
    return render_template("postal_address.html")

# ---------------- Step 6: Uploads ----------------
@app.route("/uploads", methods=["GET", "POST"])
def uploads():
    personal_id = session.get('personal_id')
    if personal_id is None:
        return redirect(url_for('personal_info'))

    if request.method == "POST":
        try:
            sql = """
            INSERT INTO Learner_Uploads
            (personal_id, id_copy, bank_confirmation, signed_contract, tax_ref_file, qualifications)
            VALUES (%s, %s, %s, %s, %s, %s)
            """
            # Files are NULL for now
            values = (personal_id, None, None, None, None, None)
            cursor.execute(sql, values)
            db.commit()
            return "Data inserted to mySQL successfully !"
        except Exception as e:
            print("Uploads Error:", e)
            return "Error inserting uploads!"
    return render_template("uploads.html")

if __name__ == "__main__":
    app.run(debug=True)
