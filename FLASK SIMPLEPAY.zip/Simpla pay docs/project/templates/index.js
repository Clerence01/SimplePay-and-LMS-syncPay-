



const previousButton = document.getElementById('previous-button');
const submitButton = document.getElementById('submit-button')


const nextButton = document.getElementById('next-button');




nextButton.addEventListener("click", function() {
    window.location.href = "form2.html";
}

);