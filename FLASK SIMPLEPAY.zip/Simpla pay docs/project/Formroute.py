from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def personal_info():
    return render_template("personalInfo.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/nextofkin")
def nextofkin():
    return render_template("nextofkin.html")

@app.route("/address")
def address():
    return render_template("address.html")

@app.route("/uploads")
def uploads():
    return render_template("uploads.html")

@app.route("/submit", methods=["POST"])
def submit():
    return "Form submitted successfully!"

if __name__ == "__main__":
    app.run(debug=True)
