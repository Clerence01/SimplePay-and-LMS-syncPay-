import pytesseract
from PIL import Image
 
img = Image.open("C:\Users\Lenovo-User\Music\Work Projects\Simple Pay integration\Simpla pay docs\project\c.png")
text = pytesseract.image_to_string(img)
print("OCR Text:", text)