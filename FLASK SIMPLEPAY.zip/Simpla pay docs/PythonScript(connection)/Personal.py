import mysql.connector

def view_p(cursor):
    cursor.execute("SELECT * FROM Personal")
    rows = cursor.fetchall()
    if rows:
        print("\n--- Personal ---")
        for row in rows:
            print(row)
    else:
        print("\n--- Personal is empty ---")


# Connect to the database
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="clerence",
    database="clerence"
)

cursor = connection.cursor()
print("Connection successful!")

while True:
    print("\nEnter personal info (or type 'exit' for Last Name to stop)")
    name = input("First Names: ")
    lastname = input("Last Name (Use UPPERCASE or type 'exit' to quit): ")
    if lastname.lower() == "exit":
        break
    
    date = input("Date of Birth (YYYY-MM-DD): ")
    dates = input("Date of Appointment (YYYY-MM-DD): ")
    idNumber = input("ID Number: ")
    job = input("Job Title: ")
    email = input("Email: ")
    tax = input("Income Tax Number: ")

    insert_p = """
        INSERT INTO Personal (FirstNames, LastName, DateofBirthdate, DateofAppointment, 
                              IDNumber, JobTitle, Email, IncomeTaxNumber)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(insert_p, (name,lastname,date,dates,idNumber,job,email,tax))
    connection.commit()
    print("Personal record inserted successfully!")

    view_p(cursor)

# Close connection
cursor.close()
connection.close()
print("Connection closed.")
