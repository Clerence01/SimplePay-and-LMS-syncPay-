import mysql.connector

def view_physical(cursor):
    cursor.execute("SELECT * FROM Physical_Address")
    rows = cursor.fetchall()
    if rows:
        print("\n--- Physical_address ---")
        for row in rows:
            print(row)
    else:
        print("\n--- Physical_Address is empty ---")


connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="clerence",
    database="clerence"
)

cursor = connection.cursor()
print(" Connection successful!")

while True:
    print("\nEnter Physical_Address (or type 'exit' to stop)")
    personal_id = input("Enter personal_id: ")
    street_no = input("street_no(start with Uppercase title): ")
    if street_no.lower() == "exit":
        break
    street_name = input("street_name: ")
    building_unit = input("building_unit: ")
    suburb = input("suburb: ")
    poastal_code = input("poastal_code: ")
    province= input("province: ")


    
    insert_physical = """
    INSERT INTO Physical_Address
    (personal_id,street_no,street_name,building_unit,suburb,poastal_code,province)
    VALUES (%s,%s, %s, %s, %s, %s, %s)
    """
    cursor.execute(insert_physical, (personal_id,street_no,street_name,building_unit,suburb,poastal_code,province))
    connection.commit()
    print("Physical address inserted successfully!")

    
    view_physical(cursor)


cursor.close()
connection.close()
print("Connection closed.")


 
