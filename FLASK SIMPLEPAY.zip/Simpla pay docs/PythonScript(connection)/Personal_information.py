from flask import Flask, request, render_template
import mysql.connector

app = Flask(__name__)

# MySQL connection
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="clerence",
    database="clerence"
)
cursor = connection.cursor()

# Create table if it doesn't exist
create_table = """
CREATE TABLE IF NOT EXISTS Personal_information (
    personal_id INT PRIMARY KEY AUTO_INCREMENT,
    First_name VARCHAR(25),
    Last_name VARCHAR(25),
    Title VARCHAR(25),
    Name_known_by VARCHAR(25),
    ID_no VARCHAR(30),
    Passport_number VARCHAR(25),
    Country_of_passport VARCHAR(25),
    Data_of_birth DATE,
    Marital_status VARCHAR(25),
    Tax_reference INT,
    No_dependents INT,
    Startdate DATE
);
"""
cursor.execute(create_table)

# Home route renders your HTML form
@app.route('/')
def form():
    return render_template('form1.html')

# Handle form submission
@app.route('/submit', methods=['POST'])
def submit():
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    title = request.form['title']
    name_known_by = request.form['name_known_by']
    id_no = request.form['id_no']
    passport = request.form.get('passport', '')  # optional
    country = request.form.get('country', '')    # optional
    dob = request.form['dob']
    marital_status = request.form['marital_status']
    tax_ref = request.form['tax_ref']
    no_dep = request.form['no_dep']
    start_date = request.form['start_date']

    insert_personal = """
    INSERT INTO Personal_information
    (First_name, Last_name, Title, Name_known_by, ID_no, Passport_number, Country_of_passport, Data_of_birth, Marital_status, Tax_reference, No_dependents, Startdate)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(insert_personal, (first_name, last_name, title, name_known_by, id_no, passport, country, dob, marital_status, tax_ref, no_dep, start_date))
    connection.commit()

    return f"Personal information for {first_name} {last_name} inserted successfully!"

if __name__ == '__main__':
    app.run(debug=True)
